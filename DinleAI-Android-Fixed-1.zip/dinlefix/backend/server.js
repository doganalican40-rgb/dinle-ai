import http from "node:http";

const PORT = process.env.PORT || 8787;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6";

function send(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": process.env.CORS_ORIGIN || "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.url !== "/api/chat" || req.method !== "POST") return send(res, 404, { error: "Not found" });
  if (!ANTHROPIC_API_KEY) return send(res, 500, { error: "ANTHROPIC_API_KEY is not configured on the server." });

  try {
    let raw = "";
    for await (const chunk of req) raw += chunk;
    const body = JSON.parse(raw || "{}");
    const robot = body.robot || {};
    const lang = body.language || "tr";

    const system = `You are ${robot.name || "Dost"}, an AI companion inside Dinle.
Persona: ${robot.persona || "Warm, empathetic and helpful."}
Respond only in the requested language code: ${lang}.
Never claim to be human. Do not diagnose or prescribe medication.
For crisis/self-harm content, encourage immediate contact with emergency services or a trusted person.
Use natural spoken language because replies may be read aloud.
Mode: ${body.mode || "balanced"}.`;

    const apiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1000,
        system,
        messages: Array.isArray(body.messages) ? body.messages : [],
      }),
    });

    const data = await apiRes.json();
    if (!apiRes.ok) return send(res, apiRes.status, { error: data?.error?.message || "AI provider error" });
    const reply = (data.content || []).filter(x => x.type === "text").map(x => x.text).join("") || "…";
    return send(res, 200, { reply });
  } catch (err) {
    return send(res, 500, { error: err?.message || "Server error" });
  }
});

server.listen(PORT, () => console.log(`Dinle AI backend listening on :${PORT}`));
