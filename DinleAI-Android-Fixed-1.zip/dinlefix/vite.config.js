import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  // The Android wrapper loads the built app from file:///android_asset/public/.
  // Relative asset URLs are therefore required; absolute /assets/... URLs break
  // inside the WebView and result in a blank screen.
  base: './',
  plugins: [react()],
  build: { outDir: 'dist', emptyOutDir: true }
});
