import React from 'react';
import { createRoot } from 'react-dom/client';
import { Capacitor } from '@capacitor/core';
import App from './App.jsx';
import './native-bridge.js';

window.DINLE_API_URL = import.meta.env.VITE_API_URL || '';
window.DINLE_IS_NATIVE = Capacitor.isNativePlatform();

createRoot(document.getElementById('root')).render(<App />);

// Show the static splash (see index.html) for at least this long, then fade it out.
// A fixed minimum dwell time (rather than "hide as soon as mounted") is what makes
// this a real 3-4 second splash instead of a flash that disappears instantly on
// fast devices.
const SPLASH_MIN_MS = 3500;
setTimeout(() => {
  const splash = document.getElementById('dinle-splash');
  if (!splash) return;
  splash.classList.add('dinle-splash-hidden');
  setTimeout(() => splash.remove(), 600);
}, SPLASH_MIN_MS);
