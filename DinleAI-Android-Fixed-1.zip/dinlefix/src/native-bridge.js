// Browser preview compatibility for the original Dinle storage API.
// Capacitor uses localStorage; the original prototype's window.storage API is optional.
if (!window.storage) {
  window.storage = {
    async get(key) {
      const value = localStorage.getItem(key);
      return value == null ? null : { value };
    },
    async set(key, value) {
      localStorage.setItem(key, value);
      return { value };
    }
  };
}
