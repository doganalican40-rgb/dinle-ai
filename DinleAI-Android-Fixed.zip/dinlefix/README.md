# Dinle AI — Android APK (boş ekran düzeltildi)

Bu sürüm React/Vite uygulamasını gerçek Android APK içine doğru şekilde paketler.

## Neden önce boş ekran çıkıyordu?
Eski sürüm APK içinde eski `www/index.html` dosyasını kullanıyor ve React/Babel'i `unpkg.com` üzerinden yüklemeye çalışıyordu. Ayrıca Vite'ın `/assets/...` şeklindeki mutlak yolları `file:///android_asset/...` WebView ortamında çalışmıyordu.

Bu sürümde:
- React uygulaması her APK build'inde `src/` üzerinden Vite ile derlenir.
- Vite `base: './'` kullanır; Android WebView'da JS/CSS yolları doğru çözülür.
- `dist/` otomatik olarak `android/app/src/main/assets/public/` içine kopyalanır.
- Eski statik `www/` kopyası kaldırıldı.
- GitHub Actions otomatik debug APK üretip Artifact olarak yükler.

## GitHub'dan APK üretme
1. ZIP'i GitHub repository'sine yükle.
2. **Actions → Build Dinle AI APK → Run workflow** seç.
3. İşlem bitince **Artifacts → DinleAI-debug-apk** dosyasını indir.

İstersen repository Variables bölümünde `VITE_API_URL` değişkenini backend adresin olarak tanımlayabilirsin. Tanımlanmazsa uygulama frontend olarak yine açılır; AI backend çağrıları için URL gerekir.

## Yerelde
```bash
npm install
npm run android:sync
cd android
gradle :app:assembleDebug
```

APK:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Gerçekçi AI görüntülü görüşme

Görüntülü görüşme ekranı, yapılandırıldığında LiveAvatar kullanır. Bu katmanda avatar WebRTC üzerinden gerçek zamanlı video/ses akışı sağlar; dudak senkronu ve doğal yüz hareketleri servis tarafından üretilir. LiveAvatar'ın resmi dokümantasyonunda FULL mode'un ASR, LLM, TTS ve WebRTC'yi yönetebildiği; LITE mode'un ise video akışını yönetip konuşma katmanını uygulamaya bıraktığı belirtiliyor.

Backend `.env` içine şunları ekleyin:

- `LIVEAVATAR_API_KEY`
- `LIVEAVATAR_AVATAR_ID`
- `LIVEAVATAR_CONTEXT_ID`
- `LIVEAVATAR_SANDBOX=true` (test için)

Android build sırasında GitHub repository variables içine `VITE_BACKEND_BASE_URL` ekleyin. Değeri backend'in HTTPS adresi olmalı; örnek olarak `https://api.senin-domainin.com`.

Avatar ve konuşma bağlamını LiveAvatar panelinden oluşturup ilgili ID'leri backend'de tutun. API anahtarını Android uygulamasına koymayın.

## VIP / Google Play Billing

VIP is implemented as one auto-renewing monthly subscription product:

- Product ID: `dinle_vip_monthly`
- Product type: Subscription
- Billing library: Google Play Billing 9.1.0
- VIP gates: voice input/replies, realistic video calls, and narrated story mode
- Story mode includes vector high-resolution scene illustrations

In Google Play Console, create a subscription with product ID `dinle_vip_monthly` and an auto-renewing monthly base plan. Set the localized title, description and price in Play Console; the app intentionally does not hard-code a price.

For production release, purchase tokens should also be sent to a secure backend and verified with the Google Play Developer API before granting entitlement. The current Android client acknowledges purchased subscriptions and restores active purchases on startup.
