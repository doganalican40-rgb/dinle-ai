import http from "node:http";

const PORT = process.env.PORT || 8787;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6";
const LIVEAVATAR_API_KEY = process.env.LIVEAVATAR_API_KEY;
const LIVEAVATAR_AVATAR_ID = process.env.LIVEAVATAR_AVATAR_ID;
const LIVEAVATAR_CONTEXT_ID = process.env.LIVEAVATAR_CONTEXT_ID;
const LIVEAVATAR_SANDBOX = String(process.env.LIVEAVATAR_SANDBOX || "false").toLowerCase() === "true";

function send(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": process.env.CORS_ORIGIN || "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.method === "POST" && req.url === "/api/liveavatar/embed") {
    if (!LIVEAVATAR_API_KEY) return send(res, 503, { error: "LIVEAVATAR_API_KEY sunucuda ayarlı değil." });
    if (!LIVEAVATAR_AVATAR_ID || !LIVEAVATAR_CONTEXT_ID) {
      return send(res, 503, { error: "LIVEAVATAR_AVATAR_ID ve LIVEAVATAR_CONTEXT_ID ayarlanmalı." });
    }
    try {
      const apiRes = await fetch("https://api.liveavatar.com/v2/embeddings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": LIVEAVATAR_API_KEY,
        },
        body: JSON.stringify({
          avatar_id: LIVEAVATAR_AVATAR_ID,
          context_id: LIVEAVATAR_CONTEXT_ID,
          is_sandbox: LIVEAVATAR_SANDBOX,
        }),
      });
      const data = await apiRes.json().catch(() => ({}));
      if (!apiRes.ok || !data?.data?.url) {
        return send(res, apiRes.status || 502, { error: data?.message || data?.error || "LiveAvatar embed oluşturulamadı." });
      }
      return send(res, 200, { url: data.data.url });
    } catch (err) {
      return send(res, 502, { error: err?.message || "LiveAvatar bağlantı hatası." });
    }
  }

  if (req.url !== "/api/chat" || req.method !== "POST") return send(res, 404, { error: "Not found" });
  if (!ANTHROPIC_API_KEY) return send(res, 500, { error: "ANTHROPIC_API_KEY is not configured on the server." });

  try {
    let raw = "";
    for await (const chunk of req) raw += chunk;
    const body = JSON.parse(raw || "{}");
    const robot = body.robot || {};
    const lang = body.language || "tr";

    const system = `You are ${robot.name || "Dost"}, an AI companion inside Dinle.
Persona: ${robot.persona || "Warm, empathetic and helpful."}
Respond only in the requested language code: ${lang}.
Never claim to be human. Do not diagnose or prescribe medication.
For crisis/self-harm content, encourage immediate contact with emergency services or a trusted person.
Use natural spoken language because replies may be read aloud.
Mode: ${body.mode || "balanced"}.`;

    const apiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1000,
        system,
        messages: Array.isArray(body.messages) ? body.messages : [],
      }),
    });

    const data = await apiRes.json();
    if (!apiRes.ok) return send(res, apiRes.status, { error: data?.error?.message || "AI provider error" });
    const reply = (data.content || []).filter(x => x.type === "text").map(x => x.text).join("") || "…";
    return send(res, 200, { reply });
  } catch (err) {
    return send(res, 500, { error: err?.message || "Server error" });
  }
});

server.listen(PORT, () => console.log(`Dinle AI backend listening on :${PORT}`));
