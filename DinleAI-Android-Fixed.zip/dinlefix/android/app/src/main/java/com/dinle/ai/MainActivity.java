package com.dinle.ai;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.QueryPurchasesParams;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static final String VIP_PRODUCT_ID = "dinle_vip_monthly";
    private WebView webView;
    private PermissionRequest pendingRequest;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private BillingClient billingClient;
    private ProductDetails vipProduct;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION}, 100);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B1020);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.addJavascriptInterface(new BillingBridge(), "DinleBilling");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    pendingRequest = request;
                    ArrayList<String> perms = new ArrayList<>();
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) perms.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) perms.add(Manifest.permission.RECORD_AUDIO);
                    }
                    if (perms.isEmpty()) request.grant(request.getResources());
                    else requestPermissions(perms.toArray(new String[0]), 101);
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                pendingGeoOrigin = origin; pendingGeoCallback = callback;
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) callback.invoke(origin, true, false);
                else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 102);
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/public/index.html");
        setupBilling();
    }

    private void setupBilling() {
        billingClient = BillingClient.newBuilder(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .setListener((billingResult, purchases) -> {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                        for (Purchase p : purchases) handlePurchase(p);
                    } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                        sendBillingEvent("error", "Google Play ödeme başlatılamadı: " + billingResult.getDebugMessage());
                    }
                }).build();
        connectBilling();
    }

    private void connectBilling() {
        if (billingClient == null || billingClient.isReady()) { queryVip(); return; }
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) queryVip();
                else sendBillingEvent("error", "Google Play bağlantısı kurulamadı.");
            }
            @Override public void onBillingServiceDisconnected() { }
        });
    }

    private void queryVip() {
        if (billingClient == null || !billingClient.isReady()) return;
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(VIP_PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build())).build();
        billingClient.queryProductDetailsAsync(params, (result, detailsResult) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && detailsResult != null) {
                List<ProductDetails> details = detailsResult.getProductDetailsList();
                if (details != null && !details.isEmpty()) vipProduct = details.get(0);
            }
            queryExistingPurchases();
        });
    }

    private void queryExistingPurchases() {
        if (billingClient == null || !billingClient.isReady()) return;
        billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(), (result, purchases) -> {
            boolean active = false;
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (Purchase p : purchases) {
                    if (p.getProducts().contains(VIP_PRODUCT_ID) && p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        active = true; handlePurchase(p);
                    }
                }
            }
            sendBillingEvent("status", active ? "active" : "inactive");
        });
    }

    private void handlePurchase(Purchase purchase) {
        if (!purchase.getProducts().contains(VIP_PRODUCT_ID)) return;
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        if (!purchase.isAcknowledged()) {
            AcknowledgePurchaseParams ack = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.acknowledgePurchase(ack, result -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) sendBillingEvent("status", "active");
            });
        } else sendBillingEvent("status", "active");
    }

    private void sendBillingEvent(String type, String value) {
        if (webView == null) return;
        String safe = value == null ? "" : value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        webView.post(() -> webView.evaluateJavascript("window.onDinleBillingEvent && window.onDinleBillingEvent('" + type + "','" + safe + "')", null));
    }

    public class BillingBridge {
        @JavascriptInterface public void getStatus() { runOnUiThread(MainActivity.this::queryExistingPurchases); }
        @JavascriptInterface public void purchaseVip() {
            runOnUiThread(() -> {
                if (billingClient == null || !billingClient.isReady()) { sendBillingEvent("error", "Google Play hazır değil. Birkaç saniye sonra tekrar dene."); connectBilling(); return; }
                if (vipProduct == null) { sendBillingEvent("error", "VIP ürünü Google Play'de henüz yapılandırılmamış."); return; }
                List<ProductDetails.SubscriptionOfferDetails> offers = vipProduct.getSubscriptionOfferDetails();
                if (offers == null || offers.isEmpty()) { sendBillingEvent("error", "Aylık VIP teklif bilgisi bulunamadı."); return; }
                String offerToken = offers.get(0).getOfferToken();
                BillingFlowParams.ProductDetailsParams productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(vipProduct).setOfferToken(offerToken).build();
                BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(productParams)).build();
                billingClient.launchBillingFlow(MainActivity.this, flow);
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 101 && pendingRequest != null) {
            boolean ok = true; for (int r: results) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) pendingRequest.grant(pendingRequest.getResources()); else pendingRequest.deny(); pendingRequest = null;
        } else if (requestCode == 102 && pendingGeoCallback != null) {
            boolean ok = false; for (int r: results) if (r == PackageManager.PERMISSION_GRANTED) ok = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, ok, false); pendingGeoCallback = null;
        }
    }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
