# Dinle AI Android

This Android project is intentionally built as a lightweight native WebView shell.
The React/Vite output is copied to `app/src/main/assets/public/` by
`scripts/sync-android-assets.mjs`.

Build toolchain:
- JDK 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- compileSdk/targetSdk 35

The GitHub Actions workflow generates the Gradle wrapper with Gradle 8.9
when the repository does not already contain one.
