# Dinle AI — UI / functionality update

- Reworked the visual direction toward the supplied dark navy / purple / gold cosmic reference.
- Added high-resolution vector logo: `public/assets/dinle-logo.svg`.
- Added high-resolution vector cosmic background: `public/assets/dinle-cosmic-bg.svg`.
- Restored a dedicated video-call button beside Settings in the main header.
- Removed VIP gating from video calls and feature access for this first phase; VIP purchase UI is no longer exposed from Settings.
- Made onboarding questions mandatory: no Skip controls, and Next cannot proceed without a response. Age must be 1–120.
- Choice questions now select an answer first; the user must press Next, preventing accidental advancement.
- Fixed font-size controls by applying the selected scale to the whole app using the persisted setting.
- Updated the Android WebView asset bundle (`android/app/src/main/assets/public/index.html`) with the current React source so the packaged Android shell uses the fixes even without a fresh Vite build.
