# APK build fixes

- Removed unused `@capacitor/android` and `@capacitor/cli` from the web build dependencies.
- Kept `@capacitor/core` because `src/main.jsx` uses `Capacitor.isNativePlatform()`.
- Updated Android Gradle Plugin from 8.5.2 to 8.7.3.
- Standardized the CI Gradle version to 8.9.
- Kept JDK 17, which is required by AGP 8.7.
- Added Java 17 compile options.
- Increased Gradle heap to 3 GB and disabled daemon/parallel build/cache for deterministic CI.
- Removed `npx cap add android` / `npx cap sync android` from CI because this repository already contains a hand-built Android WebView shell.
- CI now copies Vite `dist/` directly into Android assets and builds the existing Android project.
- CI no longer deletes Gradle caches during the build.
