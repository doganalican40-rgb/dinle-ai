import React from 'react';
import { createRoot } from 'react-dom/client';
import { Capacitor } from '@capacitor/core';
import App from './App.jsx';
import './native-bridge.js';

window.DINLE_API_URL = import.meta.env.VITE_API_URL || '';
window.DINLE_IS_NATIVE = Capacitor.isNativePlatform();

createRoot(document.getElementById('root')).render(<App />);
