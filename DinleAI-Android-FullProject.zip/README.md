# Dinle AI — Android APK Project

Bu proje Dinle AI'nin Android'e paketlenmeye hazır Capacitor + React sürümüdür.

## 1. Gereksinimler
- Node.js 20+
- Android Studio
- Android SDK + platform tools
- JDK 17+

## 2. Kurulum
```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

## 3. Backend
```bash
cd backend
npm install
cp .env.example .env
# .env içine ANTHROPIC_API_KEY yaz
npm start
```

Android uygulamasına backend adresini build sırasında ver:
```bash
VITE_API_URL=https://SUNUCU-ADRESIN/api/chat npm run build
npx cap sync android
```

Windows PowerShell:
```powershell
$env:VITE_API_URL="https://SUNUCU-ADRESIN/api/chat"
npm run build
npx cap sync android
```

## 4. Android Studio
```bash
npx cap open android
```
Android Studio'da Build > Generate App Bundles or APKs > Generate APKs.

## 5. Özellikler
- 4 AI robot/persona: Dost, Mentor, Koç, Bilge
- Metin + mikrofonla konuşma
- AI cevabını cihaz TTS ile sesli okutma
- Kamera/görüntülü görüşme arayüzü
- 6 dil
- Onboarding
- Kriz/concern yönlendirmesi
- Ücretsiz kullanım kotası

Not: AI video/avatar tarafı gerçek zamanlı bir video modeli değildir. Kamera önizlemesi gerçektir; AI tarafı avatar + ses deneyimidir. Gerçek yüz animasyonlu AI video için ayrıca WebRTC/Realtime avatar servisi bağlanmalıdır.
